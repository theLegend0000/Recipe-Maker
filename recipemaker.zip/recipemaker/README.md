# Prerequisites
- Python 3.x

## Setup
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver

